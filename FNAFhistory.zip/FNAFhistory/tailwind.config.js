/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}", "./*.html"], // Adicione os caminhos dos seus arquivos aqui
  theme: {
    extend: {},
  },
  plugins: [],
}